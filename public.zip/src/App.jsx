import { Component, useState } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import './App.css'
import Registration from './pages/auth/registration/registration'
import Wrapper from './pages/layout/wrapper/wrapper';
import Login from './pages/auth/login/login';
import ProductCreate from './pages/products/product_create/productcreate';
import ProductList from './pages/products/product_list/productlist';
import ProductDetails from './pages/products/product_details/productdetails';
import ProfileDetails from './pages/auth/profile_details/profile';
import ProductUpdate from './pages/products/product_update/productupdate';
import toast from 'react-hot-toast';

function Private_router({ children }) {
  const token = localStorage.getItem('token')

  return token != null || token != undefined ? (
    children

  ) : (
    <>
      <Navigate to={'/'} />
      {toast.success("Login First")};
    </>
  )
}
function App() {
  const public_router = [
    {
      path: "/",
      Component: <Login />
    },
    {
      path: "/reg",
      Component: <Registration />
    },

  ]
  const private_router = [

    {
      path: "/profile",
      Component: <ProfileDetails />
    },
    {
      path: "/pcreate",
      Component: <ProductCreate />
    },
    {
      path: "/plist",
      Component: <ProductList />
    },
    {
      path: "/product-details/:id",
      Component: <ProductDetails />
    },
    {
      path: "/profile",
      Component: <ProfileDetails />
    },
    {
      path: "/pupdate",
      Component: <ProductUpdate />
    },

  ]

  return (
    <>
      <Router>
        <Wrapper>
          <Routes>
            {public_router.map((item) => (
              <Route path={item.path} element={item.Component} />
            ))}
          </Routes>

          <Routes>
            {private_router.map((item) => (
              <Route path={item.path} element={<Private_router>{item.Component}</Private_router>} />
            ))}
          </Routes>
        </Wrapper>
      </Router>

    </>
  )
}

export default App