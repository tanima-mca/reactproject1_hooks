import React, { useEffect, useState } from "react";
import { TextField, Button, Typography, Box ,Stack} from "@mui/material";
import { useForm } from "react-hook-form";
import axiosInstance from "../../../api/axios";
import { endPoints } from "../../../api/endPoints";
import { useParams } from "react-router-dom";
import toast from "react-hot-toast";

const ProductUpdate = () => {
  const { id } = useParams();
  const { register, handleSubmit, reset, formState: { errors } } = useForm();
  const [isLoading, setIsLoading] = useState(false);
  const [image, setImage] = useState(null);



  // useEffect(() => {
  //   const fetchProductDetails = async () => {
  //     setIsLoading(true);
  //     try {
  //       const response = await axiosInstance.get(endPoints.products.update + id);
  //       if (response.status === 200 && response.data.data) {
  //         reset(response.data.data); 
  //       } else {
  //         toast.error("Failed to fetch product details.");
  //       }
  //     } catch (error) {
  //       toast.error(error.message || "An error occurred while fetching product details.");
  //     } finally {
  //       setIsLoading(false);
  //     }

  //   };

  //   fetchProductDetails();
  // }, [id]);


  const onSubmit = async (data) => {
    setIsLoading(true);

    const formData = new FormData();
    formData.append("title", data.title);
    formData.append("description", data.description);
    formData.append("image", data.image[0]);


    try {
      const response = await axiosInstance.post(endPoints.products.update, formData);
      if (response.status === 200) {
        toast.success("Product updated successfully!");
      } else {
        toast.error("Failed to update product.");
      }
    } catch (error) {
      toast.error(error.message || "An error occurred while updating the product.");
    } finally {
      setIsLoading(false);
    }
    reset();
    setImage(null);
  };

  return (
    <>
      <Box
        sx={{
          maxWidth: 500,
          margin: "auto",
          mt: 5,
          p: 3,
          border: "1px solid #ccc",
          borderRadius: 2,
          boxShadow: 2,
          marginBottom: 8,
          background: "#ffff8d"
        }}
      >
        <Typography variant="h4" gutterBottom align="center">
          Update Product
        </Typography>
        <form onSubmit={handleSubmit(onSubmit)}>
          {/* <TextField
          label="Product ID"
          name="id"
          value={id}
          disabled
          fullWidth
          margin="normal"
        /> */}
          <TextField
            label="Title"
            {...register("title", { required: "Title is required" })}
            fullWidth
            margin="normal"
            error={!!errors.title}
            helperText={errors.title?.message}
          />
          <TextField
            label="Description"
            {...register("description", { required: "Description is required" })}
            multiline
            rows={4}
            fullWidth
            margin="normal"
            error={!!errors.description}
            helperText={errors.description?.message}
          />
           <TextField
            {...register("image", { required: "Image is required" })}
            type="file"
            variant="outlined"
            onChange={(e) => setImage(e.target.files[0])}
            error={!!errors.image}
            helperText={errors.image?.message}
            fullWidth
            sx={{ backgroundColor: "white", borderRadius: "5px", mb: 2 }}
          />
          {image && (
            <Stack
              direction="column"
              justifyContent="center"
              alignItems="center"
              style={{ marginBottom: "1rem", gap: "0.5rem" }}
            >
              <img
                src={URL.createObjectURL(image)}
                alt="Preview"
                height={100}
                width="auto"
                style={{ borderRadius: "10px" }}
              />
              <Typography variant="caption" display="block">
                Selected file: {image.name}
              </Typography>
            </Stack>
          )}


          <Button
            type="submit"
            variant="contained"
            color="primary"
            fullWidth
            disabled={isLoading}
            sx={{ mt: 3 }}
          >
            {isLoading ? "Updating..." : "Update Product"}
          </Button>
        </form>
      </Box>
    </>
  );
};

export default ProductUpdate;
