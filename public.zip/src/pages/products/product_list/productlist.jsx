

import React, { useEffect, useState } from "react";
import {
  Grid,
  Paper,
  Typography,
  Card,
  CardContent,
  Button,
  CardActions,
  Box,
  Pagination,
} from "@mui/material";
import toast from "react-hot-toast";
import axiosInstance, { productt } from "../../../api/axios";
import { endPoints } from "../../../api/endPoints";
import SweetAlertComponent from "../../../ui/sweetAlert";
import { Link } from "react-router-dom";

const ProductList = () => {
  const [products, setProducts] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [totalPages, setTotalPages] = useState(1);
  const [currentPage, setCurrentPage] = useState(1);
  const [deleteId, setDeleteId] = useState(null);
  const [modal, setModal] = useState(false);


  useEffect(() => {
    const fetchProducts = async () => {
      setIsLoading(true);
      const formData = new FormData();
      formData.append("page", currentPage);
      formData.append("perPage", 10);

      try {
        const response = await axiosInstance.post(endPoints.products.list, formData);

        if (response.status === 200) {
          setProducts(response.data.data);
          setTotalPages(response.data.totalPages || 1);
        } else {
          toast.error(response.data.message || "Failed to fetch products.");
        }
      } catch (error) {
        toast.error(error.message || "An error occurred while fetching products.");
      } finally {
        setIsLoading(false);
      }
    };

    fetchProducts();
  }, [currentPage]);


  const handleDelete = async (page = 1) => {
    const formData = new FormData();
    formData.append("id", deleteId);

    try {
      const response = await axiosInstance.post(endPoints.products.delete, formData);

      if (response.status === 200) {
        toast.success("Product deleted successfully!");


        const updatedResponse = await axiosInstance.post(endPoints.products.list, { page, perPage: 10 });
        setProducts(updatedResponse.data.data);
        setTotalPages(response.data.totalPages || 1);
      } else {
        toast.error("Failed to delete product.");
      }
    } catch (error) {
      toast.error(error.message || "An error occurred while deleting the product.");
    } finally {
      setModal(false);
    }
  };

  const handlePageChange = (event, page) => {
    setCurrentPage(page);
  };

  return (
    <>
      <Grid
        container
        justifyContent="center"
        alignItems="center"
        style={{ minHeight: "100vh", background: "#f4f6f8", padding: 20 }}
      >
        <Paper style={{ width: "100%", maxWidth: 800, padding: 20 }}>
          <Typography variant="h5" align="center" gutterBottom>
            Product List
          </Typography>


          <Grid container spacing={3}>
            {products.length > 0 ? (
              products.map((product) => (
                <Grid item key={product._id} xs={12} sm={6} md={4}>
                  <Card>
                    <CardContent>
                      <Box display="flex" justifyContent="center" alignItems="center" height="150px">
                        <img
                          src={productt(product.image)}
                          height="100px"
                          alt={product.title}
                        />
                      </Box>
                      <Box display="flex" justifyContent="center" alignItems="center" mt={2}>
                        <Typography variant="h6" component="div">
                          {product.title}
                        </Typography>
                      </Box>
                      <Box display="flex" justifyContent="center" alignItems="center" mt={1}>
                        <Typography variant="body2" color="text.secondary">
                          {product.description}
                        </Typography>
                      </Box>
                    </CardContent>
                    <CardActions>
                      <Box display="flex" justifyContent="space-between" width="100%">
                        <Link to={`/product-details/${product._id}`} style={{ textDecoration: "none" }}>
                          <Button variant="contained" size="small" color="primary">
                            View Details
                          </Button>
                        </Link>
                        <Button
                          variant="contained"
                          size="small"
                          color="secondary"
                          onClick={() => {
                            setDeleteId(product._id);
                            setModal(true);
                          }}
                        >
                          Delete
                        </Button>
                      </Box>
                    </CardActions>
                  </Card>
                </Grid>
              ))
            ) : (
              <Grid item xs={12}>
                <Typography align="center">
                  {isLoading ? "Loading products..." : "No products found."}
                </Typography>
              </Grid>
            )}
          </Grid>
        </Paper>
      </Grid>


      {modal && (
        <SweetAlertComponent
          confirm={handleDelete}
          cancle={() => setModal(false)}
          title="Are You Sure?"
          subtitle="You will not be able to recover this product"
          type="warning"
        />
      )}
      {products.length !== 0 ? <Box display="flex" justifyContent="center" mt={4}>
        <Pagination
          count={totalPages}
          page={currentPage}
          onChange={handlePageChange}
        />
      </Box> : ""}


    </>
  );
};

export default ProductList;
