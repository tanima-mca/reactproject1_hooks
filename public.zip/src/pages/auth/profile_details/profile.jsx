import React, { useState, useEffect } from 'react';
import { Box, Typography, Button, CircularProgress } from '@mui/material';
import axiosInstance from '../../../api/axios';
import { endPoints } from '../../../api/endPoints';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';

const ProfileDetails = () => {
    const [userData, setUserData] = useState(null);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();


    useEffect(() => {
        const fetchProfileDetails = async () => {
            const token = localStorage.getItem("token");
            if (!token) {
                toast.error('You must be logged in to view your profile');
                navigate('/');
                return;
            }

            try {
                const response = await axiosInstance.get(endPoints.auth.profiledatails, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });

                if (response.status === 200) {
                    setUserData(response.data.data);
                } else {
                    toast.error('Failed to fetch profile data.');
                }
            } catch (error) {
                toast.error('Error fetching profile details.');
                navigate('/');
            } finally {
                setLoading(false);
            }
        };

        fetchProfileDetails();
    }, [navigate]);


    const handleLogout = () => {
        localStorage.removeItem('token');
        navigate('/');
    };

    return (
        <Box
            sx={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                maxWidth: 600,
                margin: '0 auto',
                padding: 4,
                borderRadius: 3,
                boxShadow: 10,
                backgroundColor: '#f0f0f0',
            }}
        >
            <Typography variant="h4" align="center" mb={4}>
                Profile Details
            </Typography>

            {loading ? (
                <CircularProgress />
            ) : (
                <>
                    {userData ? (
                        <>
                            <Box display="flex" flexDirection="column" alignItems="center" mb={3}>
                                <img
                                    src={userData.profile_pic}
                                    alt="Profile"
                                    width={120}
                                    height={120}
                                  style={{ borderRadius: '50%', objectFit: 'cover' }}
                                />
                                <Typography variant="h6" mt={2}>
                                    First Name: {userData.first_name}
                                </Typography>
                                <Typography variant="h6" mt={2}>
                                    Last Name: {userData.last_name}
                                </Typography>
                                <Typography variant="body1" color="textSecondary" mt={2}>
                                    Email: {userData.email}
                                </Typography>
                            </Box>

                            <Button
                                variant="contained"
                                color="secondary"
                                onClick={handleLogout}
                                sx={{ mt: 2 }}
                            >
                                Logout
                            </Button>
                        </>
                    ) : (
                        <Typography variant="body1" color="textSecondary">
                            No profile data available.
                        </Typography>
                    )}
                </>
            )}
        </Box>
    );
};

export default ProfileDetails;
