import React, { useState } from 'react';
import { Stack, TextField, Button, Box, Typography } from '@mui/material';
// import Radio from '@mui/material/Radio';
// import RadioGroup from '@mui/material/RadioGroup';
// import FormControlLabel from '@mui/material/FormControlLabel';
// import FormControl from '@mui/material/FormControl';
import { useForm } from 'react-hook-form';
import toast from "react-hot-toast";
import axiosInstance from '../../../api/axios';
import { endPoints } from '../../../api/endPoints';
import { Link } from 'react-router-dom'
import { Key } from '@mui/icons-material'

const Registration = () => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors }
  } = useForm()
  const [image, setImage] = useState()


  const ClickFuntion = async (data) => {
    const formData = new FormData()
    formData.append("first_name", data.first_name)
    formData.append("last_name", data.last_name)
    formData.append("email", data.email)
    formData.append("password", data.password)
    formData.append("profile_pic", image)
    try {
      const response = await axiosInstance.post(endPoints.auth.register, formData)
      if (response.status === 200) {
        toast.success(response.data.message || "Registration successful!");
        localStorage.setItem("token", response.data.token)
      } else {
        toast.error(response.data.message || "Registration failed!");
      }
      console.log("Registration Successful:", response.data.message);
    } catch (error) {
      toast.error(response.data.message);
    }
    reset();
    setImage(null);
  };


  return (
    <>
      <Box
        component="form"
        sx={{
          display: 'flex',
          flexDirection: 'column',
          maxWidth: 400,
          margin: '0 auto',
          padding: 4,
          borderRadius: 3,
          boxShadow: 10,
          marginTop: 6,
          marginBottom: 6,
          backgroundColor: '#b9f6ca',
          '& .MuiTextField-root': { marginBottom: 2 },
        }}
      >
        <Typography variant="h4" component="h1" marginBottom={4} align='center'>
          <b> Registration Form</b>
        </Typography>
        <TextField
          {...register("first_name", {
            required: "First_name is required"
          })}
          label="first_name"
          variant="outlined"
          required
          error={errors.first_name}
          helperText={errors.first_name && errors.first_name.message}
        />
        <TextField
          {...register("last_name", {
            required: "last_name is required"
          })}
          label="last_name"
          required
          variant="outlined"
          error={errors.last_name}
          helperText={errors.last_name && errors.last_name.message}
        />
        <TextField
          {...register("email", {
            required: "email is required",
            pattern: {
              value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i,
              message: "Invalid email format"

            }
          })}
          label="email"
          required
          type="email"
          variant="outlined"
          error={errors.email}
          helperText={errors.email && errors.email.message}
        />
        <TextField
          {...register("password", {
            required: "password is required"
          })}
          label="password"
          required
          variant="outlined"
          color="secondary"
          type="password"
          error={errors.password}
          helperText={errors.password && errors.password.message}
        />
        <TextField
          {...register("profile_pic", {

            required: "profile_pic is required",
          })}
          type="file"
          variant='outlined'
          color='secondary'
          onChange={(e) => setImage(e.target.files[0])}
          error={!!errors.profile_pic}
          helperText={errors.profile_pic && errors.profile_pic.message}
          fullWidth
          sx={{ backgroundColor: 'white', borderRadius: '5px', mb: 4 }}
        />
       
        <Stack direction={{ xs: "column-reverse", sm: "row" }} style={{ display: `${image ? 'flex' : 'none'}`, justifyContent: 'center', alignItems: 'center', marginBottom: '1rem', gap: '1rem' }}>
          <img src={image && URL.createObjectURL(image)} height={100} width={"auto"} style={{ borderRadius: '10px' }} />
          {image && (
            <Typography variant="caption" display="block" sx={{ mt: 1 }}>
              Selected file: {image.name}
            </Typography>
          )}
        </Stack>

        <Button variant='outlined' onClick={handleSubmit(ClickFuntion)} sx={{ mt: 3, fontSize: 18, color: '#1a237e' }}><b>Register Now!</b></Button>
        <br />
        <Link to="/">
          <Button sx={{mt: 3, fontSize: 14, color:'#01579b'}}
            variant="outlined"
            color="primary"
            fullWidth
            startIcon={<Key />}
          >
            Already have an account? Login
          </Button>
        </Link>
      </Box>
    </>
  )
}

export default Registration


