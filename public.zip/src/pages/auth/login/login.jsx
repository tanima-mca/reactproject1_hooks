import React from "react";
import {
  Grid,
  Paper,
  Avatar,
  TextField,
  Button,
  Typography,
} from "@mui/material";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import { useForm } from "react-hook-form";
import toast from "react-hot-toast";
import axiosInstance from "../../../api/axios";
import { endPoints } from "../../../api/endPoints";
// import image1 from "../pages/images/backgroundimage.jpg";



const Login = () => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm();

  const handleLogin = async (data) => {
    const formData = new FormData();
    formData.append("email", data.email);
    formData.append("password", data.password);

    try {
      const response = await axiosInstance.post(endPoints.auth.login, formData);
      if (response.status === 200) {
        toast.success(response.data.message || "Login successful!");
        localStorage.setItem("token", response.data.token);
      } else {
        toast.error(response.data.message || "Login failed!");
      }
    } catch (error) {
      toast.error(response.data.message || "An unexpected error occurred!");
    }
    reset();
  };

  return (
    <>
    <Grid
      container
      justifyContent="center"
      alignItems="center"
      style={{
        minHeight: "100vh",
        background: "#bbdefb",
      //  backgroundImage: `url(${image1})`,
      //   backgroundSize: "cover",
      //   backgroundPosition: "center",
      }}
    >
      <Paper elevation={10} style={{ padding: 20, width: 280, borderRadius: 10 ,background:"#f8bbd0"}}>
        <Grid align="center">
          <Avatar style={{ background: "#5d4037" }}>
            <LockOutlinedIcon />
          </Avatar>
          <Typography
            variant="h5"
            style={{ margin: "10px 0", color: "#000" }}
          >
            Sign In
          </Typography>
        </Grid>

        <form onSubmit={handleSubmit(handleLogin)}>
          <TextField
            {...register("email", {
              required: "Email is required",
              pattern: {
                value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i,
                message: "Invalid email format",
              },
            })}
            label="Email"
            placeholder="Enter email"
            fullWidth
            margin="normal"
            error={!!errors.email}
            helperText={errors.email && errors.email.message}
          />

          <TextField
            {...register("password", {
              required: "Password is required",
            })}
            label="Password"
            placeholder="Enter password"
            type="password"
            fullWidth
            margin="normal"
            error={!!errors.password}
            helperText={errors.password && errors.password.message}
          />

          <Button
            type="submit"
            variant="contained"
            fullWidth
            style={{ margin: "10px 0", background: "#3949ab", color: "#fff" }}
          >
            Sign In
          </Button>
        </form>
      </Paper>
    </Grid>
    </>
  );
};

export default Login;
